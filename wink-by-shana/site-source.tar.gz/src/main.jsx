import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { CalendarCheck, Camera, Car, ChevronLeft, ChevronRight, Menu, MessageCircle, Phone, ShoppingBag, Sparkles, X } from 'lucide-react';
import './styles.css';

const slug = 'wink-by-shana';
const base = `/generated/${slug}`;
const PHONE_DISPLAY = '+1 845-616-2489';
const PHONE = 'tel:+18456162489';
const WHATSAPP = 'https://wa.me/18456162489';
const BOOK = 'https://wink-by-shana.square.site/s/appointments';
const DIRECTIONS = 'https://www.google.com/maps/dir/?api=1&destination=272%20McNamara%20Rd%20Side%20entrance%2C%20Spring%20Valley%2C%20NY%2010977&destination_place_id=ChIJa1SVCBTdwokRoBFyeJIZPm4';
const INSTAGRAM = 'https://www.instagram.com/winkbyshana';
const BUY = 'https://app.siteboro.com/lets-go?business=wink-by-shana&site=wink-by-shana.siteboro.com';

const services = [
  {title:'Couples Teeth Whitening', desc:'Teeth whitening session for 2 at the same time', price:'$650.00', time:'2 hrs', tone:'pearl'},
  {title:'Teeth Whitening', desc:'10% off for brides & grooms', price:'$350.00', time:'1 hr 30 mins', tone:'champagne'},
  {title:'Teeth Whitening Touch-Up', desc:'A verified Square touch-up appointment', price:'$175.00', time:'50 mins', tone:'pearl'},
  {title:'Lash Lift + Tint', desc:'Lift and tint service from the booking menu', price:'$120.00', time:'1 hr', tone:'rose'},
  {title:'Brow Lamination + Tint', desc:'Brow lamination with tint', price:'$100.00', time:'1 hr', tone:'umber'},
  {title:'Lash + Brow Combo', desc:'Lamination+tint and lift+tint, all at the same time', price:'$210.00', time:'1 hr', tone:'rose'},
  {title:'Brow Tint + Shaping', desc:'Brow tint and shaping appointment', price:'$35.00', time:'30 mins', tone:'umber'},
  {title:'Brow Tint', desc:'Brow tint appointment', price:'$25.00', time:'20 mins', tone:'umber'},
  {title:'Spray Tan - Full Body', desc:'Rapid rinse & organic', price:'$85.00', time:'30 mins', tone:'bronze'},
  {title:'Spray Tan - Half Body', desc:'Upper or lower body', price:'$45.00', time:'30 mins', tone:'bronze'},
  {title:'Travel Fee', desc:'Please inquire about pricing before booking your appointment', price:'Price varies', time:'30 mins', tone:'champagne'},
];

const gallery = [
  {src:`${base}/images/gallery-1.jpg`, alt:'Official Wink By Shana prep and aftercare gallery image 1'},
  {src:`${base}/images/gallery-2.jpg`, alt:'Official Wink By Shana prep and aftercare gallery image 2'},
  {src:`${base}/images/gallery-3.jpg`, alt:'Official Wink By Shana prep and aftercare gallery image 3'},
  {src:`${base}/images/gallery-4.jpg`, alt:'Official Wink By Shana prep and aftercare gallery image 4'},
  {src:`${base}/images/gallery-5.jpg`, alt:'Official Wink By Shana prep and aftercare gallery image 5'},
  {src:`${base}/images/gallery-6.jpg`, alt:'Official Wink By Shana prep and aftercare gallery image 6'},
];

function sendEvent(type) {
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get('owner') === '1') return;
    const payload = JSON.stringify({
      eventId: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`,
      timestamp: new Date().toISOString(),
      leadId: params.get('lead') || 'wink-by-shana-preview',
      siteSlug: slug,
      siteName: 'Wink By Shana',
      host: window.location.host,
      pageUrl: window.location.href,
      visitorId: localStorage.getItem('siteboroVisitor') || (() => { const id = crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`; localStorage.setItem('siteboroVisitor', id); return id; })(),
      type
    });
    navigator.sendBeacon?.('/siteboro-interest-events.json', payload);
  } catch {}
}

function Header() {
  const [open, setOpen] = useState(false);
  const links = [['Services','#services'], ['Gallery','#gallery'], ['Hours','#visit']];
  return <>
    <header className="topbar" aria-label="Main navigation">
      <a className="brand" href="#top" aria-label="Wink By Shana home"><img src={`${base}/images/logo.png`} alt="Wink By Shana Inc logo"/><span>Wink By Shana</span></a>
      <nav className="desktop-nav">{links.map(([l,h]) => <a key={l} href={h}>{l}</a>)}<a href={BOOK}>Book</a></nav>
      <div className="header-actions"><a className="ghost" href={PHONE}><Phone size={16}/> Call</a><a className="primary" href={BOOK}><CalendarCheck size={16}/> Book</a><button className="menu-btn" aria-label="Open menu" onClick={()=>setOpen(true)}><Menu/></button></div>
    </header>
    <div className={`mobile-panel ${open?'show':''}`} aria-hidden={!open}>
      <button className="close" aria-label="Close menu" onClick={()=>setOpen(false)}><X/></button>
      {links.map(([l,h]) => <a key={l} href={h} onClick={()=>setOpen(false)}>{l}</a>)}
      <a href={BOOK}>Book on Square</a><a href={WHATSAPP}>WhatsApp</a><a href={DIRECTIONS}>Directions</a>
    </div>
  </>
}

function Hero() {
  return <section id="top" className="hero">
    <div className="hero-copy">
      <p className="eyebrow"><Sparkles size={16}/> Beauty salon · Spring Valley / Pomona, NY</p>
      <h1><span>Smile brighter.</span><span>Brows sharper.</span><span>Lashes lifted.</span></h1>
      <p className="hero-text">A polished standalone preview for Wink By Shana Inc — anchored in verified Square booking services, WhatsApp contact, official gallery media, and the 4.9-star Google Maps listing.</p>
      <div className="cta-row"><a className="big primary" href={BOOK}>Book on Square</a><a className="big ghost" href={WHATSAPP}><MessageCircle/> WhatsApp</a><a className="big dark" href={DIRECTIONS}><Car/> Directions</a></div>
      <p className="note">Prices and availability are confirmed through Square at booking time.</p>
    </div>
    <div className="hero-card" aria-label="Wink By Shana verified media hero">
      <img className="hero-logo" src={`${base}/images/logo.png`} alt="Wink By Shana Inc logo" width="1600" height="1067" />
      <img className="hero-photo" src={`${base}/images/maps-photo.jpg`} alt="Google Maps listing photo for Wink By Shana" width="1011" height="1024" />
      <div className="shine" />
      <div className="rating">4.9 Google rating · 32 reviews in lead record</div>
    </div>
    <a className="scroll-cue" href="#services">View verified services</a>
  </section>
}

function ServiceCarousel() {
  const [index, setIndex] = useState(0);
  const count = services.length;
  const next = () => setIndex(i => (i + 1) % count);
  const prev = () => setIndex(i => (i - 1 + count) % count);
  return <section id="services" className="services section-pad">
    <div className="section-title"><p>Verified Square menu</p><h2>Appointment services with exact published names and prices.</h2></div>
    <div className="carousel-controls"><button aria-label="Previous service" onClick={prev}><ChevronLeft/></button><button aria-label="Next service" onClick={next}><ChevronRight/></button></div>
    <div className="service-viewport"><div className="service-track" style={{transform:`translateX(calc(${index} * -1 * var(--card-step)))`}}>
      {services.map(s => <article className={`service-card ${s.tone}`} key={s.title}>
        <div><p>{s.time}</p><h3>{s.title}</h3><span>{s.desc}</span></div><strong>{s.price}</strong><a href={BOOK}>Book now</a>
      </article>)}
    </div></div>
    <p className="fineprint">Travel fee varies; please inquire before booking. Pricing can change on Square.</p>
  </section>
}

function Gallery() {
  const [index, setIndex] = useState(0);
  const ref = useRef(null);
  const reduced = useMemo(() => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches, []);
  useEffect(() => {
    if (reduced) return;
    let visible = false;
    const obs = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; }, {threshold:.35});
    if(ref.current) obs.observe(ref.current);
    const timer = setInterval(() => { if(visible && !document.hidden) setIndex(i => (i + 1) % gallery.length); }, 3000);
    return () => { obs.disconnect(); clearInterval(timer); };
  }, [reduced]);
  const manual = (dir) => setIndex(i => (i + dir + gallery.length) % gallery.length);
  return <section id="gallery" className="gallery section-pad" ref={ref}>
    <div className="section-title light"><p>Official media</p><h2>Prep & aftercare imagery from the published Square site.</h2></div>
    <div className="gallery-stage">
      <button aria-label="Previous gallery image" onClick={()=>manual(-1)}><ChevronLeft/></button>
      <div className="gallery-window"><div className="gallery-track" style={{transform:`translateX(-${index*100}%)`}}>{gallery.map((g,i)=><figure key={g.src}><img src={g.src} alt={g.alt} width="1067" height="1600" loading={i===0?'eager':'lazy'} decoding="async"/><figcaption>Official Square media #{i+1}</figcaption></figure>)}</div></div>
      <button aria-label="Next gallery image" onClick={()=>manual(1)}><ChevronRight/></button>
    </div>
  </section>
}

function Visit() {
  return <section id="visit" className="visit section-pad">
    <div className="visit-card"><p className="eyebrow">Hours & location</p><h2>Book online, then confirm details through Square or WhatsApp.</h2><p>Maps lists 272 McNamara Rd Side entrance, Spring Valley, NY 10977. Square footer labels the area as Pomona, NY.</p><div className="visit-actions"><a href={PHONE}><Phone/> {PHONE_DISPLAY}</a><a href={WHATSAPP}><MessageCircle/> WhatsApp</a><a href={DIRECTIONS}><Car/> Directions</a><a href={INSTAGRAM}><Camera/> Instagram</a></div></div>
    <div className="hours"><h3>Square published hours</h3><dl><dt>Mon</dt><dd>11:00AM - 10:00PM</dd><dt>Tue/Wed/Thu</dt><dd>9:30AM - 10:00PM</dd><dt>Fri</dt><dd>9:30AM - 1:00PM</dd><dt>Sat</dt><dd>Closed</dd><dt>Sun</dt><dd>11:00AM - 4:00PM</dd></dl></div>
  </section>
}

function App(){
  useEffect(()=>sendEvent('preview_opened'), []);
  return <><Header/><main><Hero/><section className="brand-read section-pad"><div className="line-art" aria-hidden="true"><svg viewBox="0 0 320 90"><path d="M10 45 C75 0 130 0 190 45 C130 90 75 90 10 45Z"/><circle cx="98" cy="45" r="18"/><path d="M205 45 C240 25 280 25 315 45"/></svg></div><div><p className="eyebrow">Brand read</p><h2>Less directory listing, more appointment ritual.</h2><p>This preview turns the Square service list into a premium beauty-site experience while preserving the real booking path, WhatsApp number, logo, published service names, prices, and official social link.</p></div></section><ServiceCarousel/><Gallery/><Visit/><section className="final"><h2>Ready for a brighter appointment flow?</h2><p>Use the verified booking, call, WhatsApp, or directions links — no fake checkout or invented service path.</p><div className="cta-row"><a className="big primary" href={BOOK}>Book on Square</a><a className="big ghost" href={PHONE}>Call {PHONE_DISPLAY}</a></div></section></main><footer><img src={`${base}/images/logo.png`} alt="Wink By Shana Inc logo"/><span>Preview built from verified Maps + Square facts.</span></footer><a className="buy-pill" href={BUY} onClick={()=>sendEvent('buy_clicked')}><ShoppingBag size={16}/> If you like it, buy it!</a></>
}

createRoot(document.getElementById('root')).render(<App/>);
