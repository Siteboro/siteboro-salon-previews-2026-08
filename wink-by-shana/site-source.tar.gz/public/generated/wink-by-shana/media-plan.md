# Media plan

Real media first. Assets in `images/` are copied from Google Maps or official Square sources.

- `logo.png`: official Square logo.
- `gallery-1.jpg` through `gallery-6.jpg`: official Square gallery/prep-aftercare images embedded in published page JSON.
- `maps-photo.jpg`: visible Google Maps listing image captured from Maps image URL.

No Higgsfield/video provider access was available. Hero uses verified still photography and CSS shine/mask motion; `video/provider-status.md` records the blocker.
