# Provider prompt draft (not submitted)

A cinematic macro beauty studio sequence for Wink By Shana: pearly smile reflection, brow brush, lash lift pad, champagne black salon card, slow slider camera move, soft ring light, no fake staff faces, no text except verified logo if supplied, 6 seconds, 16:9.

Status: not submitted because Higgsfield/provider UI access was not available in this environment.
